# Android音乐播放器增强版 - 项目说明文档

## 项目概述

本项目是基于原有Android音乐播放器的增强版本，主要增加了以下功能：

1. **网易云音乐API集成** - 支持在线音乐播放和歌词搜索
2. **AI智能推荐系统** - 基于用户偏好的个性化音乐推荐
3. **开屏法律声明页面** - 包含用户协议和隐私协议

## 新增功能详细说明

### 1. 网易云音乐API集成

#### 功能特性
- 在线音乐搜索和播放
- 歌词获取和显示
- 歌曲详情获取
- 推荐歌曲获取

#### 技术实现
- 使用Retrofit进行网络请求
- 集成第三方网易云音乐API服务
- 支持多种音质选择

#### 相关文件
- `app/src/main/java/com/example/musicplayer/api/NeteaseMusicApi.java`
- `app/src/main/java/com/example/musicplayer/api/ApiClient.java`

### 2. AI智能推荐系统

#### 推荐算法
- **基于内容的推荐**：根据歌曲特征和用户偏好进行推荐
- **协同过滤推荐**：基于相似用户的听歌记录进行推荐
- **混合推荐**：结合多种算法提供更准确的推荐

#### 技术实现
- 用户偏好学习和存储
- 歌曲特征分析
- 相似度计算算法
- 推荐结果排序和过滤

#### 相关文件
- `app/src/main/java/com/example/musicplayer/recommendation/MusicRecommendationEngine.java`

### 3. 开屏法律声明页面

#### 功能特性
- 应用启动时显示法律声明
- 用户协议和隐私协议链接
- 同意/不同意选择
- 不同意则退出应用，同意则进入主页面

#### 页面组成
- **开屏页面**：显示法律声明和协议链接
- **用户协议页面**：详细的用户使用协议
- **隐私协议页面**：隐私保护政策说明

#### 相关文件
- `app/src/main/java/com/example/musicplayer/SplashActivity.java`
- `app/src/main/java/com/example/musicplayer/UserAgreementActivity.java`
- `app/src/main/java/com/example/musicplayer/PrivacyPolicyActivity.java`
- `app/src/main/res/layout/activity_splash.xml`
- `app/src/main/res/layout/activity_user_agreement.xml`
- `app/src/main/res/layout/activity_privacy_policy.xml`

## 项目结构变更

### 新增文件
```
app/src/main/java/com/example/musicplayer/
├── SplashActivity.java                    # 开屏页面
├── UserAgreementActivity.java             # 用户协议页面
├── PrivacyPolicyActivity.java             # 隐私协议页面
├── api/
│   ├── NeteaseMusicApi.java              # 网易云音乐API接口
│   └── ApiClient.java                    # API客户端
└── recommendation/
    └── MusicRecommendationEngine.java    # 推荐引擎

app/src/main/res/
├── layout/
│   ├── activity_splash.xml               # 开屏页面布局
│   ├── activity_user_agreement.xml       # 用户协议页面布局
│   └── activity_privacy_policy.xml       # 隐私协议页面布局
└── drawable/
    ├── legal_notice_background.xml       # 法律声明背景
    ├── button_primary.xml                # 主要按钮样式
    ├── button_outline.xml                # 轮廓按钮样式
    ├── ic_music_note.xml                 # 音乐图标
    └── ic_arrow_back.xml                 # 返回箭头图标
```

### 修改文件
- `app/src/main/AndroidManifest.xml` - 添加新Activity和权限
- `app/build.gradle` - 添加网络请求相关依赖

## 法律文档

### 法律声明
"本应用仅供学习交流使用，请勿用于商业用途。"

### 用户协议
包含服务条款、用户义务、知识产权、免责声明等内容。

### 隐私协议
包含信息收集、使用、保护、共享等隐私保护相关条款。

## 技术依赖

### 新增依赖
```gradle
// Network
implementation 'com.squareup.retrofit2:retrofit:2.9.0'
implementation 'com.squareup.retrofit2:converter-gson:2.9.0'
implementation 'com.google.code.gson:gson:2.10.1'
```

### 权限要求
```xml
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
```

## 使用说明

### 开发环境要求
- Android Studio Arctic Fox或更高版本
- Android SDK API 24或更高版本
- Java 8或更高版本

### 编译和运行
1. 使用Android Studio打开项目
2. 同步Gradle依赖
3. 连接Android设备或启动模拟器
4. 点击运行按钮编译和安装应用

### API配置
如需使用自己的网易云音乐API服务，请修改`ApiClient.java`中的`BASE_URL`常量。

## 注意事项

1. **API服务**：项目中使用的是第三方网易云音乐API服务，实际使用时需要确保API服务的可用性。

2. **版权声明**：音乐内容版权归原作者所有，本应用仅供学习交流使用。

3. **网络权限**：应用需要网络权限来获取在线音乐内容。

4. **用户协议**：首次启动应用时，用户必须同意用户协议和隐私协议才能继续使用。

## 联系信息

如有技术问题或建议，请通过应用内反馈功能联系开发团队。

---

**版本**：2.0 Enhanced  
**更新日期**：2025年6月13日  
**开发团队**：Android音乐播放器开发组

