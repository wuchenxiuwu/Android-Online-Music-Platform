package com.example.musicplayer.api;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface NeteaseMusicApi {
    
    // 搜索歌曲
    @GET("/search")
    Call<SearchResponse> searchSongs(@Query("keywords") String keywords, 
                                   @Query("type") int type, 
                                   @Query("limit") int limit);
    
    // 获取歌曲详情
    @GET("/song/detail")
    Call<SongDetailResponse> getSongDetail(@Query("ids") String ids);
    
    // 获取歌曲播放地址
    @GET("/song/url")
    Call<SongUrlResponse> getSongUrl(@Query("id") String id, 
                                   @Query("br") int bitrate);
    
    // 获取歌词
    @GET("/lyric")
    Call<LyricResponse> getLyric(@Query("id") String id);
    
    // 获取推荐歌曲
    @GET("/recommend/songs")
    Call<RecommendResponse> getRecommendSongs();
    
    // 获取每日推荐
    @GET("/recommend/resource")
    Call<DailyRecommendResponse> getDailyRecommend();
}

