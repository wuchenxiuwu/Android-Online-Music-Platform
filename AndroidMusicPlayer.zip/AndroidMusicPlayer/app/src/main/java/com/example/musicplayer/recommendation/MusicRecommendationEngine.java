package com.example.musicplayer.recommendation;

import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
import java.util.Collections;
import java.util.Comparator;

public class MusicRecommendationEngine {
    
    private Map<String, Map<String, Double>> userPreferences;
    private Map<String, Map<String, Double>> songFeatures;
    
    public MusicRecommendationEngine() {
        this.userPreferences = new HashMap<>();
        this.songFeatures = new HashMap<>();
    }
    
    // 更新用户偏好
    public void updateUserPreference(String userId, String genre, double rating) {
        userPreferences.computeIfAbsent(userId, k -> new HashMap<>())
                      .put(genre, rating);
    }
    
    // 添加歌曲特征
    public void addSongFeatures(String songId, Map<String, Double> features) {
        songFeatures.put(songId, features);
    }
    
    // 基于内容的推荐
    public List<String> getContentBasedRecommendations(String userId, List<String> availableSongs, int limit) {
        Map<String, Double> userPref = userPreferences.get(userId);
        if (userPref == null || userPref.isEmpty()) {
            return getPopularSongs(availableSongs, limit);
        }
        
        List<SongScore> songScores = new ArrayList<>();
        
        for (String songId : availableSongs) {
            Map<String, Double> features = songFeatures.get(songId);
            if (features != null) {
                double score = calculateContentScore(userPref, features);
                songScores.add(new SongScore(songId, score));
            }
        }
        
        Collections.sort(songScores, (a, b) -> Double.compare(b.score, a.score));
        
        List<String> recommendations = new ArrayList<>();
        for (int i = 0; i < Math.min(limit, songScores.size()); i++) {
            recommendations.add(songScores.get(i).songId);
        }
        
        return recommendations;
    }
    
    // 计算内容相似度得分
    private double calculateContentScore(Map<String, Double> userPref, Map<String, Double> songFeatures) {
        double score = 0.0;
        int commonFeatures = 0;
        
        for (String feature : userPref.keySet()) {
            if (songFeatures.containsKey(feature)) {
                score += userPref.get(feature) * songFeatures.get(feature);
                commonFeatures++;
            }
        }
        
        return commonFeatures > 0 ? score / commonFeatures : 0.0;
    }
    
    // 获取热门歌曲（当用户偏好不足时的备选方案）
    private List<String> getPopularSongs(List<String> availableSongs, int limit) {
        List<String> popular = new ArrayList<>(availableSongs);
        Collections.shuffle(popular);
        return popular.subList(0, Math.min(limit, popular.size()));
    }
    
    // 协同过滤推荐（简化版）
    public List<String> getCollaborativeRecommendations(String userId, Map<String, List<String>> userListenHistory, 
                                                       List<String> availableSongs, int limit) {
        List<String> userHistory = userListenHistory.get(userId);
        if (userHistory == null || userHistory.isEmpty()) {
            return getPopularSongs(availableSongs, limit);
        }
        
        Map<String, Double> similarityScores = new HashMap<>();
        
        // 找到相似用户
        for (String otherUserId : userListenHistory.keySet()) {
            if (!otherUserId.equals(userId)) {
                double similarity = calculateUserSimilarity(userHistory, userListenHistory.get(otherUserId));
                if (similarity > 0.1) { // 相似度阈值
                    similarityScores.put(otherUserId, similarity);
                }
            }
        }
        
        // 基于相似用户推荐歌曲
        Map<String, Double> songRecommendationScores = new HashMap<>();
        for (String similarUserId : similarityScores.keySet()) {
            List<String> similarUserHistory = userListenHistory.get(similarUserId);
            double userSimilarity = similarityScores.get(similarUserId);
            
            for (String songId : similarUserHistory) {
                if (!userHistory.contains(songId) && availableSongs.contains(songId)) {
                    songRecommendationScores.put(songId, 
                        songRecommendationScores.getOrDefault(songId, 0.0) + userSimilarity);
                }
            }
        }
        
        List<SongScore> songScores = new ArrayList<>();
        for (String songId : songRecommendationScores.keySet()) {
            songScores.add(new SongScore(songId, songRecommendationScores.get(songId)));
        }
        
        Collections.sort(songScores, (a, b) -> Double.compare(b.score, a.score));
        
        List<String> recommendations = new ArrayList<>();
        for (int i = 0; i < Math.min(limit, songScores.size()); i++) {
            recommendations.add(songScores.get(i).songId);
        }
        
        return recommendations;
    }
    
    // 计算用户相似度
    private double calculateUserSimilarity(List<String> user1History, List<String> user2History) {
        if (user1History.isEmpty() || user2History.isEmpty()) {
            return 0.0;
        }
        
        int commonSongs = 0;
        for (String song : user1History) {
            if (user2History.contains(song)) {
                commonSongs++;
            }
        }
        
        return (double) commonSongs / Math.sqrt(user1History.size() * user2History.size());
    }
    
    // 混合推荐
    public List<String> getHybridRecommendations(String userId, Map<String, List<String>> userListenHistory,
                                               List<String> availableSongs, int limit) {
        List<String> contentBased = getContentBasedRecommendations(userId, availableSongs, limit / 2);
        List<String> collaborative = getCollaborativeRecommendations(userId, userListenHistory, availableSongs, limit / 2);
        
        List<String> hybrid = new ArrayList<>();
        hybrid.addAll(contentBased);
        
        for (String song : collaborative) {
            if (!hybrid.contains(song) && hybrid.size() < limit) {
                hybrid.add(song);
            }
        }
        
        // 如果还不够，用热门歌曲填充
        if (hybrid.size() < limit) {
            List<String> popular = getPopularSongs(availableSongs, limit - hybrid.size());
            for (String song : popular) {
                if (!hybrid.contains(song)) {
                    hybrid.add(song);
                }
            }
        }
        
        return hybrid;
    }
    
    // 歌曲得分类
    private static class SongScore {
        String songId;
        double score;
        
        SongScore(String songId, double score) {
            this.songId = songId;
            this.score = score;
        }
    }
}

