package com.example.musicplayer;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class PrivacyPolicyActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_privacy_policy);

        TextView policyContent = findViewById(R.id.policy_content);
        
        String privacyPolicy = "隐私协议\n\n" +
                "1. 信息收集\n" +
                "1.1 我们可能收集您的设备信息、使用习惯、音乐偏好等数据，以提供更好的服务。\n" +
                "1.2 我们不会收集您的个人敏感信息，如身份证号、银行卡号等。\n\n" +
                "2. 信息使用\n" +
                "2.1 收集的信息仅用于改善用户体验、提供个性化推荐服务。\n" +
                "2.2 我们不会将您的个人信息出售给第三方。\n\n" +
                "3. 信息保护\n" +
                "3.1 我们采用行业标准的安全措施保护您的个人信息。\n" +
                "3.2 我们会定期审查和更新安全措施，确保信息安全。\n\n" +
                "4. 信息共享\n" +
                "4.1 除法律法规要求外，我们不会向第三方披露您的个人信息。\n" +
                "4.2 在获得您明确同意的情况下，我们可能与合作伙伴分享必要信息。\n\n" +
                "5. Cookie使用\n" +
                "5.1 我们可能使用Cookie技术来改善用户体验。\n" +
                "5.2 您可以通过设备设置管理Cookie的使用。\n\n" +
                "6. 未成年人保护\n" +
                "6.1 我们特别重视未成年人的隐私保护。\n" +
                "6.2 未成年人使用本应用需在监护人同意下进行。\n\n" +
                "7. 联系我们\n" +
                "如您对隐私政策有任何疑问，请通过应用内反馈功能联系我们。\n\n" +
                "本隐私协议自用户点击同意之日起生效。";
        
        policyContent.setText(privacyPolicy);
    }
}

