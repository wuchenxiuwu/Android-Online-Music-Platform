package com.example.musicplayer;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class UserAgreementActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_agreement);

        TextView agreementContent = findViewById(R.id.agreement_content);
        
        String userAgreement = "用户协议\n\n" +
                "1. 服务条款\n" +
                "欢迎使用本音乐播放器应用（以下简称"本应用"）。在使用本应用前，请您仔细阅读并同意以下用户协议。\n\n" +
                "2. 服务内容\n" +
                "本应用为用户提供音乐播放、搜索、推荐等服务。我们致力于为用户提供优质的音乐体验。\n\n" +
                "3. 用户义务\n" +
                "3.1 用户应遵守国家相关法律法规，不得利用本应用从事违法活动。\n" +
                "3.2 用户不得恶意攻击、破坏本应用的正常运行。\n" +
                "3.3 用户应保护好自己的账号信息，不得将账号借给他人使用。\n\n" +
                "4. 知识产权\n" +
                "4.1 本应用中的音乐内容版权归原作者或版权方所有。\n" +
                "4.2 用户仅可在本应用内欣赏音乐，不得进行商业用途的传播。\n\n" +
                "5. 免责声明\n" +
                "5.1 本应用仅提供技术服务，不对音乐内容的准确性、完整性承担责任。\n" +
                "5.2 因不可抗力因素导致的服务中断，本应用不承担责任。\n\n" +
                "6. 协议修改\n" +
                "本协议可能会根据法律法规或业务需要进行修改，修改后的协议将在应用内公布。\n\n" +
                "7. 争议解决\n" +
                "如发生争议，双方应友好协商解决；协商不成的，可向有管辖权的人民法院提起诉讼。\n\n" +
                "本协议自用户点击同意之日起生效。";
        
        agreementContent.setText(userAgreement);
    }
}

