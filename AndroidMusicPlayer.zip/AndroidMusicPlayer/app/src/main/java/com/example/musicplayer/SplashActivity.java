package com.example.musicplayer;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        TextView legalNotice = findViewById(R.id.legal_notice);
        TextView userAgreement = findViewById(R.id.user_agreement);
        TextView privacyPolicy = findViewById(R.id.privacy_policy);
        Button agreeButton = findViewById(R.id.agree_button);
        Button disagreeButton = findViewById(R.id.disagree_button);

        // 设置法律声明文本
        legalNotice.setText("本应用仅供学习交流使用，请勿用于商业用途。");

        // 用户协议点击事件
        userAgreement.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SplashActivity.this, UserAgreementActivity.class);
                startActivity(intent);
            }
        });

        // 隐私协议点击事件
        privacyPolicy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SplashActivity.this, PrivacyPolicyActivity.class);
                startActivity(intent);
            }
        });

        // 同意按钮点击事件
        agreeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 进入主页面
                Intent intent = new Intent(SplashActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        });

        // 不同意按钮点击事件
        disagreeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 退出应用
                finish();
                System.exit(0);
            }
        });
    }
}

